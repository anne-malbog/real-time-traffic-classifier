"""Build a COCO-class-space copy of the test split, for a fair baseline comparison.

The pretrained baseline model outputs COCO's 80 classes; our fine-tuned model
outputs this project's 5 classes (Ambulance, Bus, Car, Motorcycle, Truck).
Raw class-id integers don't mean the same thing in both spaces (our Car=2
happens to coincide with COCO's car=2, but our Bus=1 does NOT coincide with
COCO's bus=5) — validating the baseline directly against our dataset.yaml
silently compares wrong class pairs (see evaluation/metrics.py's docstring).

This module remaps ground truth into COCO's own indices for the four classes
that actually have a COCO equivalent (car, motorcycle, bus, truck), dropping
Ambulance entirely — COCO has no ambulance class, so there's no fair baseline
number to compute for it; that's reported separately as a fine-tuned-only
capability, not a case where baseline "loses".

Usage: build_coco_overlap_dataset(coco_names) -> path to a temp dataset.yaml
"""

from __future__ import annotations

import shutil
from pathlib import Path

import yaml

# Our dataset class name -> COCO class name. Only classes with a genuine
# semantic COCO equivalent are included; Ambulance is intentionally absent.
OUR_TO_COCO_NAME = {
    "Bus": "bus",
    "Car": "car",
    "Motorcycle": "motorcycle",
    "Truck": "truck",
}

PROCESSED_TEST_DIR = Path("data/processed")
TMP_DIR = Path("outputs/metrics/tmp_coco_overlap")


def build_coco_overlap_dataset(coco_names: dict[int, str], split: str = "test") -> str:
    """coco_names: the baseline model's `model.names` dict (id -> name)."""
    coco_name_to_id = {v: k for k, v in coco_names.items()}

    with open("data/dataset.yaml") as f:
        our_meta = yaml.safe_load(f)
    our_names = our_meta["names"]  # our index -> our name, e.g. {0: 'Ambulance', ...}

    # our class id -> coco class id, only for names with a real COCO match
    our_id_to_coco_id = {}
    for our_id, our_name in enumerate(our_names):
        coco_name = OUR_TO_COCO_NAME.get(our_name)
        if coco_name is not None:
            our_id_to_coco_id[our_id] = coco_name_to_id[coco_name]

    src_images = PROCESSED_TEST_DIR / "images" / split
    src_labels = PROCESSED_TEST_DIR / "labels" / split
    dst_images = TMP_DIR / "images" / split
    dst_labels = TMP_DIR / "labels" / split
    if TMP_DIR.exists():
        shutil.rmtree(TMP_DIR)
    dst_images.mkdir(parents=True, exist_ok=True)
    dst_labels.mkdir(parents=True, exist_ok=True)

    for label_path in src_labels.glob("*.txt"):
        remapped_lines = []
        with open(label_path) as f:
            for line in f:
                parts = line.split()
                if not parts:
                    continue
                our_id = int(parts[0])
                if our_id not in our_id_to_coco_id:
                    continue  # drop Ambulance (or anything else with no COCO match)
                coco_id = our_id_to_coco_id[our_id]
                remapped_lines.append(" ".join([str(coco_id), *parts[1:]]))

        (dst_labels / label_path.name).write_text("\n".join(remapped_lines))
        img_path = src_images / (label_path.stem + ".jpg")
        if img_path.exists():
            shutil.copy2(img_path, dst_images / img_path.name)

    dataset_yaml = {
        "path": str(TMP_DIR.resolve()),
        "train": "images/test",  # unused placeholders — only `split` is evaluated
        "val": "images/test",
        "test": "images/test",
        "nc": len(coco_names),
        "names": coco_names,
    }
    yaml_path = TMP_DIR / "dataset.yaml"
    with open(yaml_path, "w") as f:
        yaml.safe_dump(dataset_yaml, f, sort_keys=False)

    kept_classes = sorted(set(OUR_TO_COCO_NAME.values()))
    print(f"Built COCO-overlap eval set at {TMP_DIR} — classes: {kept_classes} (Ambulance excluded, no COCO equivalent)")
    return str(yaml_path)
