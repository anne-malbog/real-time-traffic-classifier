"""Phase 2, step 4: baseline (pretrained) vs. fine-tuned comparison.

A fair comparison requires care: the baseline outputs COCO's 80 classes,
the fine-tuned model outputs this project's 5 classes, and raw class-id
integers don't mean the same thing in both spaces. This script:

  1. Evaluates the baseline against a COCO-class-remapped copy of the test
     set (evaluation/coco_overlap.py), restricted to the 4 classes that
     genuinely exist in COCO (car, motorcycle, bus, truck).
  2. Evaluates the fine-tuned model normally (its own 5-class dataset.yaml),
     then reports both (a) the same 4-class overlap subset, for the fair
     head-to-head against baseline, and (b) its full 5-class performance
     including Ambulance — a class the baseline has no concept of at all,
     so that number is reported separately, not as a baseline "win/loss".

Usage:

    python -m evaluation.compare_models --baseline yolo11n.pt --finetuned outputs/training_runs/stage1_finetune/weights/best.pt

"""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

from ultralytics import YOLO

from evaluation.coco_overlap import OUR_TO_COCO_NAME, build_coco_overlap_dataset
from evaluation.metrics import benchmark_speed, evaluate_detection_metrics
from evaluation.plots import plot_baseline_vs_finetuned

OUTPUT_DIR = Path("outputs/metrics")
OVERLAP_CLASSES = sorted(OUR_TO_COCO_NAME.keys())  # ["Bus", "Car", "Motorcycle", "Truck"]


def _macro_average(per_class: dict, keys: list[str]) -> dict:
    metrics = ["precision", "recall", "ap50", "ap50_95"]
    out = {m: sum(per_class[k][m] for k in keys) / len(keys) for m in metrics}
    return {"precision": out["precision"], "recall": out["recall"], "map50": out["ap50"], "map50_95": out["ap50_95"]}


def run_comparison(baseline_path: str, finetuned_path: str, data_yaml: str, device: str, split: str) -> dict:
    print(f"Building COCO-class-space overlap eval set (excludes Ambulance — no COCO equivalent)...")
    baseline_model_names = YOLO(baseline_path).names
    coco_overlap_yaml = build_coco_overlap_dataset(baseline_model_names, split)

    print(f"Evaluating baseline on overlap classes {OVERLAP_CLASSES}: {baseline_path}")
    baseline_metrics = evaluate_detection_metrics(baseline_path, coco_overlap_yaml, device, split)
    baseline_speed = benchmark_speed(baseline_path, data_yaml, device)
    baseline = {**baseline_metrics, **baseline_speed}

    print(f"Evaluating fine-tuned (full 5 classes): {finetuned_path}")
    finetuned_metrics = evaluate_detection_metrics(finetuned_path, data_yaml, device, split)
    finetuned_speed = benchmark_speed(finetuned_path, data_yaml, device)
    finetuned_full = {**finetuned_metrics, **finetuned_speed}

    # Fair head-to-head: fine-tuned's overlap-only subset (excludes Ambulance,
    # same 4 classes the baseline was evaluated on).
    finetuned_overlap_overall = _macro_average(finetuned_metrics["per_class"], OVERLAP_CLASSES)
    finetuned_overlap = {
        "model": finetuned_path,
        "overall": finetuned_overlap_overall,
        "per_class": {k: finetuned_metrics["per_class"][k] for k in OVERLAP_CLASSES},
        "fps": finetuned_speed["fps"],
        "avg_latency_ms": finetuned_speed["avg_latency_ms"],
        "device": finetuned_speed["device"],
    }

    return {"baseline": baseline, "finetuned_overlap": finetuned_overlap, "finetuned_full": finetuned_full}


def print_table(result: dict) -> None:
    b, f = result["baseline"]["overall"], result["finetuned_overlap"]["overall"]
    bs, fs = result["baseline"], result["finetuned_overlap"]
    print("=" * 70)
    print(f"FAIR COMPARISON — overlap classes only ({', '.join(OVERLAP_CLASSES)})")
    print(f"{'Metric':<14}{'Baseline':>15}{'Fine-Tuned':>15}")
    print("-" * 70)
    print(f"{'Precision':<14}{b['precision']:>15.3f}{f['precision']:>15.3f}")
    print(f"{'Recall':<14}{b['recall']:>15.3f}{f['recall']:>15.3f}")
    print(f"{'mAP@50':<14}{b['map50']:>15.3f}{f['map50']:>15.3f}")
    print(f"{'mAP@50-95':<14}{b['map50_95']:>15.3f}{f['map50_95']:>15.3f}")
    print(f"{'FPS':<14}{bs['fps']:>15.2f}{fs['fps']:>15.2f}")
    print(f"{'Latency (ms)':<14}{bs['avg_latency_ms']:>15.2f}{fs['avg_latency_ms']:>15.2f}")
    print("=" * 70)
    ff = result["finetuned_full"]["overall"]
    print("Fine-tuned FULL 5-class performance (includes Ambulance — no baseline equivalent to compare against):")
    print(f"  Precision={ff['precision']:.3f}  Recall={ff['recall']:.3f}  mAP50={ff['map50']:.3f}  mAP50-95={ff['map50_95']:.3f}")
    print("=" * 70)


def save_outputs(result: dict) -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    json_path = OUTPUT_DIR / "baseline_vs_finetuned.json"
    with open(json_path, "w") as f:
        json.dump(result, f, indent=2)
    print(f"Saved {json_path}")

    csv_path = OUTPUT_DIR / "baseline_vs_finetuned.csv"
    with open(csv_path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["metric", "baseline_overlap", "finetuned_overlap", "finetuned_full_5class"])
        b, fo, ff = result["baseline"]["overall"], result["finetuned_overlap"]["overall"], result["finetuned_full"]["overall"]
        for key, label in [("precision", "precision"), ("recall", "recall"), ("map50", "map50"), ("map50_95", "map50_95")]:
            writer.writerow([label, b[key], fo[key], ff[key]])
        writer.writerow(["fps", result["baseline"]["fps"], result["finetuned_overlap"]["fps"], result["finetuned_full"]["fps"]])
        writer.writerow(["avg_latency_ms", result["baseline"]["avg_latency_ms"], result["finetuned_overlap"]["avg_latency_ms"], result["finetuned_full"]["avg_latency_ms"]])
    print(f"Saved {csv_path}")

    plot_baseline_vs_finetuned(result["baseline"], result["finetuned_overlap"], str(OUTPUT_DIR / "baseline_vs_finetuned.png"))


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Compare baseline vs. fine-tuned model (class-vocabulary-aware)")
    p.add_argument("--baseline", required=True, help="Baseline (pretrained) checkpoint")
    p.add_argument("--finetuned", required=True, help="Fine-tuned checkpoint")
    p.add_argument("--data", default="data/dataset.yaml")
    p.add_argument("--device", default="cpu")
    p.add_argument("--split", default="test", choices=["train", "val", "test"])
    return p.parse_args()


if __name__ == "__main__":
    args = parse_args()
    result = run_comparison(args.baseline, args.finetuned, args.data, args.device, args.split)
    print_table(result)
    save_outputs(result)
